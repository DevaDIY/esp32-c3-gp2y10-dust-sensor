#pragma once
#include <Arduino.h>

int readDustRaw();
float adcToVadc(float adc);
float vadcToVout(float vadc);
float voutToDustMg(float vout);
float emaFilter(float v);