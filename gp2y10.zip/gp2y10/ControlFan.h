#pragma once
#include <Arduino.h>

void ControlFan_begin();
void setControlFanon(float setOn);
void setControlFanoff(float setOff);
bool ContronFanfromdust(float dust);