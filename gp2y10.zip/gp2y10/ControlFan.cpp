#include "ControlFan.h"
#include "RelayController.h"
#include "config.h"

float setFanon = 0.03;
float setFanoff = 0.02;
bool FlagOn = false;

//ประกาศ OBJ
RelayController rel(relayPins, NUM, true);

void ControlFan_begin() {
  rel.begin();
}
  
void setControlFanon(float setOn) {
  setFanon = setOn;
}

void setControlFanoff(float setOff) {
  setFanoff = setOff;
}

bool ContronFanfromdust(float dust) {
  if (dust >= setFanon) {
    FlagOn = true;
  } else if (dust <= setFanoff) {
    FlagOn = false;
  }

  if(FlagOn != rel.get(FAN)){
    rel.set(FAN, FlagOn);
    Serial.printf("FAN : %s \n", rel.get(FAN)? "ON" : "OFF");
  }
  return FlagOn;
}