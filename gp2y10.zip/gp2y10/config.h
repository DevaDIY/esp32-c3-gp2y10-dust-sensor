// ====== PIN CONFIG (ESP32-C3 Super Mini) ======
constexpr int PIN_ADC = 1;  // GPIO1 (ADC)
constexpr int PIN_LED = 2;  // GPIO2 (digital)

constexpr int relayPins[] = {3, 4};  // GPIO3 (digital)
inline size_t NUM = sizeof(relayPins) / sizeof(relayPins[0]);
enum RelayID { FAN = 0 };


// ====== Variable (dust density) ======
inline float dust = 0;
inline uint64_t lastTimereaddust = 0;
constexpr uint32_t intervalReaddust = 500;