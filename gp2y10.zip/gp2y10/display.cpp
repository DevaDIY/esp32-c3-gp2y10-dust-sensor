#include "display.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// =========================
// OLED CONFIG
// =========================
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_ADDR 0x3C
#define OLED_RESET -1

// ESP32-C3 Super Mini
// ปกติหลายบอร์ดใช้ SDA=6, SCL=7
#define OLED_SDA 6
#define OLED_SCL 7

static Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// =========================
// INTERNAL HELPER
// =========================
static void drawFrameTitle(const char* title) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  // หัวข้อบนสุด
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.print(title);

  // เส้นคั่น
  display.drawLine(0, 10, SCREEN_WIDTH - 1, 10, SSD1306_WHITE);
}

void Display_begin() {
  Wire.begin(OLED_SDA, OLED_SCL);

  if (!display.begin(SSD1306_SWITCHCAPVCC, OLED_ADDR)) {
    Serial.println("OLED init failed");
    return;
  }

  display.clearDisplay();
  display.display();
}

void Display_showBoot(const char* title) {
  drawFrameTitle(title);

  display.setTextSize(1);
  display.setCursor(0, 18);
  display.println("ESP32-C3 Super Mini");

  display.setCursor(0, 30);
  display.println("Sharp GP2Y10 Ready");

  display.setCursor(0, 50);
  display.println("warming up...");

  display.display();
}

void Display_showDust(float dustMg, float vadc, float vout, bool fanOn) {
  drawFrameTitle("Dust Monitor");

  // ค่า Dust ตัวใหญ่
  display.setTextSize(2);
  display.setCursor(0, 16);
  display.print(dustMg, 3);

  display.setTextSize(1);
  display.print(" mg/m3");

  // ค่ารอง
  display.setTextSize(1);
  display.setCursor(0, 42);
  display.print("Vadc: ");
  display.print(vadc, 3);
  display.print("V");

  display.setCursor(0, 54);
  display.print("Vout: ");
  display.print(vout, 3);
  display.print("V");

  // สถานะพัดลม
  display.setCursor(80, 54);
  display.print("Fan:");
  display.print(fanOn ? "ON" : "OFF");

  display.display();
}

void Display_showMessage(const char* line1, const char* line2) {
  display.clearDisplay();
  display.setTextColor(SSD1306_WHITE);

  display.setTextSize(1);
  display.setCursor(0, 18);
  display.println(line1);

  display.setCursor(0, 34);
  display.println(line2);

  display.display();
}