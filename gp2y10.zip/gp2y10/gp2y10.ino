#include <Arduino.h>
#include "config.h"
#include "sharpAp2y10.h"
#include <ControlFan.h>
#include "display.h"

/*
  ESP32-C3 Super Mini + Sharp GP2Y10/GP2Y1010AU0F
  - LED pin: active LOW (LOW = LED ON)
  - Sampling timing: LED ON 280us -> read ADC -> LED OFF -> wait to 10ms frame
  - IMPORTANT: AO is ~0-5V. Use voltage divider to <=3.3V before ADC.
*/


void setup() {
  Serial.begin(115200);

  ControlFan_begin();
  pinMode(PIN_LED, OUTPUT);
  digitalWrite(PIN_LED, HIGH);  // ปิด LED ไว้ก่อน (active LOW)

  analogReadResolution(12);  // 0..4095

  // ตั้ง attenuation (แนะนำ 6db สำหรับ divider นี้; หรือใช้ 2_5db)
  analogSetPinAttenuation(PIN_ADC, ADC_6db);
  // analogSetPinAttenuation(PIN_ADC, ADC_2_5db);

  Display_begin();

  Serial.println("\nESP32-C3 Super Mini + GP2Y10 start");
  Serial.println("Warm up sensor 30-60s แล้วค่อยดูค่าเฉลี่ยเพื่อปรับ V0_clean");
}

void loop() {


  if (millis() - lastTimereaddust >= intervalReaddust) {
    lastTimereaddust = millis();
    const int N = 20;  // เฉลี่ยลด noise
    long sum = 0;
    for (int i = 0; i < N; i++) sum += readDustRaw();
    float adc_avg = (float)sum / N;

    float vadc = adcToVadc(adc_avg);
    float vout = vadcToVout(vadc);
    float vout_f = emaFilter(vout);
    dust = voutToDustMg(vout_f);

    bool fanState = ContronFanfromdust(dust);
    Display_showDust(dust, vadc, vout_f, fanState);

    Serial.print("ADC(avg)=");
    Serial.print(adc_avg, 1);
    Serial.print(" | Vadc=");
    Serial.print(vadc, 3);
    Serial.print("V");
    Serial.print(" | Vout=");
    Serial.print(vout, 3);
    Serial.print("V");
    Serial.print(" | Dust~");
    Serial.print(dust, 3);
    Serial.println(" mg/m3");
  }
}