// RelayController.h
#pragma once
#include <vector>
#include <Arduino.h>

class RelayController {
public:
  
  // ถ้าบอร์ดเป็น Active-Low ให้ส่ง activeLow=true
   RelayController(const int* pins, size_t len, bool activeLow);

  void begin();
  void set(uint8_t id, bool on);
  void toggle(uint8_t id);
  bool get(uint8_t id) const ;
  void setAll(bool on);
  void offAll();

private:
  std::vector<int>  _pins;
  std::vector<bool> _state;
  bool _activeLow;

  void writePin(uint8_t i, bool on);
};
