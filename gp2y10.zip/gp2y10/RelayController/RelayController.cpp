// RelayController.cpp
#include "RelayController.h"

RelayController::RelayController(const int* pins, size_t len, bool activeLow)
  : _pins(pins, pins + len), _state(len, false), _activeLow(activeLow) {}

void RelayController::begin() {
  for (int p : _pins) if (p >= 0) pinMode(p, OUTPUT);
    offAll();
}

void RelayController::writePin(uint8_t i, bool on) {
   int pin = _pins[i];
    if (pin < 0) return;
    digitalWrite(pin, _activeLow ? !on : on);
    _state[i] = on;
}

void RelayController::set(uint8_t id, bool on) {
    writePin(id, on);
}

void RelayController::toggle(uint8_t id) {
    writePin(id, !_state[id]);
}

bool RelayController::get(uint8_t id) const {
    return _state[id];
}

void RelayController::setAll(bool on) {
  for (uint8_t i = 0; i < _pins.size(); ++i) writePin(i, on);
}

void RelayController::offAll() { setAll(false); }
