#include "RelayController.h"

enum RelayID { Relay1 = 0, Relay2 = 1, Relay3 = 2, Relay4 = 3 };
int relayPins[] = {14, 25, 26, 27};
size_t NUM = sizeof(relayPins)/ sizeof(relayPins[0]);


RelayController rel(relayPins, NUM, true);

void setup() {
  // put your setup code here, to run once:
  Serial.begin(115200);
  rel.begin();
  
}

void loop() {
  // สั่ง ON Relay1
  rel.set(Relay1, true);
  // ดึงสถานะล่าสุดของรีเลย์
  bool state1 = rel.get(Relay1);
  Serial.printf("Relay1 : %s\n", state1 ? "ON":"OFF");
  delay(1000);

  // สั่ง Toggle Relay1
  rel.toggle(Relay1);
  // ดึงสถานะล่าสุดของรีเลย์
  state1 = rel.get(Relay1);
  Serial.printf("Relay1 : %s\n", state1 ? "ON":"OFF");
  delay(1000);

  //สั่ง ON Relay ทุกตัว
  rel.setAll(true);
  state1 = rel.get(Relay1);
  bool state2 = rel.get(Relay2);
  bool state3 = rel.get(Relay3);
  bool state4 = rel.get(Relay4);
  Serial.printf("Relay1 : %s\nRelay2 : %s\nRelay3 : %s\nRelay4 : %s\n", state1 ? "ON":"OFF", state2 ? "ON":"OFF", state3 ? "ON":"OFF", state4 ? "ON":"OFF");
  delay(1000);

  //สั่ง OFF Relay ทุกตัว
  rel.offAll();
  state1 = rel.get(Relay1);
  state2 = rel.get(Relay2);
  state3 = rel.get(Relay3);
  state4 = rel.get(Relay4);
  Serial.printf("Relay1 : %s\nRelay2 : %s\nRelay3 : %s\nRelay4 : %s\n", state1 ? "ON":"OFF", state2 ? "ON":"OFF", state3 ? "ON":"OFF", state4 ? "ON":"OFF");
  delay(1000);
}
