#pragma once
#include <Arduino.h>

void Display_begin();
void Display_showBoot(const char* title = "GP2Y10 Monitor");
void Display_showDust(float dustMg, float vadc, float vout, bool fanOn);
void Display_showMessage(const char* line1, const char* line2 = "");