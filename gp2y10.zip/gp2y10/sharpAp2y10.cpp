#include "sharpAp2y10.h"
#include "config.h"


// ====== Voltage divider ratio ======
// ratio = Vadc / Vout
// ตัวอย่างแนะนำ: Rtop=17.18k, Rbottom=9.94k => ratio = 10/(18+10)=0.357
const float DIV_RATIO = 0.36652f;  // << ถ้าคุณใช้ค่า R อื่น ปรับตรงนี้

// ====== ADC settings ======
const float VREF = 3.3f;
const int ADC_MAX = 4095;

// ====== Dust conversion (approx, needs calibration) ======
float V0_clean = 0.343f;  // แรงดัน OUT ของเซนเซอร์ (ก่อนแบ่งแรงดัน) ตอนอากาศสะอาด (ประมาณ)
float vout_f = 0.0f;          // ค่า Vout ที่กรองแล้ว
const float ALPHA = 0.10f;    // 0.05–0.20 (ยิ่งน้อยยิ่งนิ่ง)

// อ่าน raw 1 ครั้งตามไทม์มิ่งเซนเซอร์
int readDustRaw() {
  digitalWrite(PIN_LED, LOW);  // LED ON
  delayMicroseconds(280);
  int adc = analogRead(PIN_ADC);  // sample
  delayMicroseconds(40);
  digitalWrite(PIN_LED, HIGH);  // LED OFF
  delayMicroseconds(9680);      // frame ~10ms
  return adc;
}

float adcToVadc(float adc) {
  return (adc * VREF) / ADC_MAX;
}

float vadcToVout(float vadc) {
  return vadc / DIV_RATIO;
}

// สูตรประมาณจากตัวอย่างที่นิยมใช้: slope ~0.5V ต่อ 1 mg/m3
float voutToDustMg(float vout) {
  float dv = vout - V0_clean;
  if (dv < 0) dv = 0;
  return (dv / 0.5f) * 0.1f;  // mg/m3 (ประมาณ)
}

float emaFilter(float v) {
  if (vout_f == 0.0f) vout_f = v;           // init ครั้งแรก
  vout_f = vout_f + ALPHA * (v - vout_f);
  return vout_f;
}